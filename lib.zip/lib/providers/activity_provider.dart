import 'package:flutter/foundation.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'dart:async';
import 'dart:math';

class ActivityProvider with ChangeNotifier {
  final List<String> _recentActivities = [];
  double _distanceTraveled = 0.0; // المسافة المقطوعة (كم)
  double _maxSpeed = 0.0; // السرعة القصوى (كم/س)
  bool _accidentDetected = false;
  StreamSubscription<AccelerometerEvent>? _accelerometerSubscription;

  List<String> get recentActivities => _recentActivities;
  double get distanceTraveled => _distanceTraveled;
  double get maxSpeed => _maxSpeed;
  bool get accidentDetected => _accidentDetected;

  ActivityProvider() {
    _startListeningToSensors();
  }

  void _startListeningToSensors() {
    try {
      _accelerometerSubscription = accelerometerEventStream().listen(
        (AccelerometerEvent event) {
          // Calculate magnitude of acceleration (in g's)
          double magnitude = sqrt(
            event.x * event.x + event.y * event.y + event.z * event.z,
          );
          // Threshold for accident detection: > 4g (based on typical crash forces)
          if (magnitude > 40) {
            // 40 m/s^2 ≈ 4g
            _accidentDetected = true;
            _recentActivities.insert(
              0,
              "Potential accident detected at ${DateTime.now().toString()}",
            );
            notifyListeners();
          }
        },
        onError: (error) {
          // Handle sensor errors (e.g., sensor not available)
          _recentActivities.insert(
            0,
            "Error accessing accelerometer: $error at ${DateTime.now().toString()}",
          );
          notifyListeners();
        },
        cancelOnError: false,
      );
    } catch (e) {
      // Handle initialization errors
      _recentActivities.insert(
        0,
        "Failed to start accelerometer: $e at ${DateTime.now().toString()}",
      );
      notifyListeners();
    }
  }

  void confirmAccident(bool confirmed) {
    if (confirmed) {
      _recentActivities.insert(
        0,
        "Accident confirmed at ${DateTime.now().toString()}",
      );
    } else {
      _recentActivities.insert(
        0,
        "Accident detection canceled at ${DateTime.now().toString()}",
      );
    }
    _accidentDetected = false;
    notifyListeners();
  }

  // إضافة نشاط جديد
  void addActivity(String activity) {
    _recentActivities.insert(0, activity);
    notifyListeners();
  }

  // تحديث المسافة المقطوعة
  void updateDistance(double distance) {
    _distanceTraveled += distance;
    notifyListeners();
  }

  // تحديث السرعة القصوى
  void updateMaxSpeed(double speed) {
    if (speed > _maxSpeed) {
      _maxSpeed = speed;
    }
    notifyListeners();
  }

  // حساب تقييم القيادة بناءً على السرعة القصوى
  String getDrivingRating() {
    if (_maxSpeed > 120) {
      return "Dangerous"; // خطيرة (أكثر من 120 كم/س)
    } else if (_maxSpeed > 80) {
      return "Normal"; // عادية (بين 80 و120 كم/س)
    } else {
      return "Excellent"; // ممتازة (أقل من 80 كم/س)
    }
  }

  // إعادة تعيين البيانات (اختياري، يمكن استخدامه يوميًا)
  void resetDailyData() {
    _distanceTraveled = 0.0;
    _maxSpeed = 0.0;
    notifyListeners();
  }

  @override
  void dispose() {
    _accelerometerSubscription?.cancel();
    super.dispose();
  }
}
