import 'package:flutter/material.dart';
import 'faq_screen.dart';
import 'contact_support_screen.dart';
import 'report_issue_screen.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Support & Help")),
      body: ListView(
        children: [
          ListTile(
            leading: const Icon(Icons.help, color: Colors.blue),
            title: const Text("FAQs"),
            subtitle: const Text("Frequently Asked Questions"),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FAQScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.contact_support, color: Colors.green),
            title: const Text("Contact Support"),
            subtitle: const Text("Get in touch with our support team"),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactSupportScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.report, color: Colors.red),
            title: const Text("Report an Issue"),
            subtitle: const Text("Report bugs or problems with the app"),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportIssueScreen())),
          ),
        ],
      ),
    );
  }
}