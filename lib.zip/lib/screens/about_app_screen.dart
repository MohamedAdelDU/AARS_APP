import 'package:flutter/material.dart';

class AboutAppScreen extends StatelessWidget {
  const AboutAppScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("About the App")),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("App Name: AARS", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text("Version: 1.0.0", style: TextStyle(fontSize: 16)),
            SizedBox(height: 10),
            Text("Developed by: Your Company", style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            Text("Legal Information", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text("All rights reserved. This app is protected by copyright laws.", style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}