import 'package:flutter/material.dart';

class ReportIssueScreen extends StatefulWidget {
  const ReportIssueScreen({super.key});

  @override
  State<ReportIssueScreen> createState() => ReportIssueScreenState();
}

class ReportIssueScreenState extends State<ReportIssueScreen> {
  final _formKey = GlobalKey<FormState>();
  final _issueController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Report an Issue")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _issueController,
                decoration: const InputDecoration(
                  labelText: "Describe the issue",
                  border: OutlineInputBorder(),
                ),
                maxLines: 5,
                validator: (value) => value == null || value.isEmpty ? "Please describe the issue" : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _submitIssue(_issueController.text);
                  }
                },
                child: const Text("Submit Issue"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submitIssue(String issue) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Thank you for reporting the issue!")));
    Navigator.pop(context);
  }
}