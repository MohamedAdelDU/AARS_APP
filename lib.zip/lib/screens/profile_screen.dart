import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => ProfileScreenState();
}

class ProfileScreenState extends State<ProfileScreen> {
  File? _image;
  String _selectedBloodType = 'None';
  final List<String> _bloodTypes = [
    'None',
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
  ];
  String? _firstName;
  String? _lastName;
  String? _email;
  String? _mobileNumber;
  String? _nationalAddress;
  bool _isEditing = false;
  bool _isLoading = false;

  // Controllers for editable fields
  final _mobileNumberController = TextEditingController();
  final _nationalAddressController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadImage();
    _loadProfileData();
  }

  Future<void> _pickImage() async {
    try {
      final pickedFile = await ImagePicker().pickImage(
        source: ImageSource.gallery,
      );
      if (pickedFile != null) {
        setState(() {
          _image = File(pickedFile.path);
        });
        await _saveImage(pickedFile.path);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Error picking image: $e")));
      }
    }
  }

  Future<void> _saveImage(String path) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('profile_image', path);
  }

  Future<void> _loadImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final path = prefs.getString('profile_image');
      if (path != null && await File(path).exists()) {
        setState(() {
          _image = File(path);
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text("Error loading image: $e")));
      }
    }
  }

  Future<void> _loadProfileData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _firstName = prefs.getString('firstName') ?? 'Unknown';
        _lastName = prefs.getString('lastName') ?? 'User';
        _email = prefs.getString('email') ?? 'No email provided';
        _mobileNumber = prefs.getString('mobileNumber') ?? 'Not provided';
        _nationalAddress = prefs.getString('nationalAddress') ?? 'Not provided';
        _selectedBloodType = prefs.getString('bloodType') ?? 'None';
        // Set controller values
        _mobileNumberController.text = _mobileNumber!;
        _nationalAddressController.text = _nationalAddress!;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error loading profile data: $e")),
        );
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _saveProfileData() async {
    setState(() {
      _isLoading = true;
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        'mobileNumber',
        _mobileNumberController.text.trim(),
      );
      await prefs.setString(
        'nationalAddress',
        _nationalAddressController.text.trim(),
      );
      await prefs.setString('bloodType', _selectedBloodType);
      setState(() {
        _mobileNumber = _mobileNumberController.text.trim();
        _nationalAddress = _nationalAddressController.text.trim();
        _isEditing = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Profile updated successfully")),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error saving profile data: $e")),
        );
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _mobileNumberController.dispose();
    _nationalAddressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Profile", style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: Icon(
              _isEditing ? Icons.close : Icons.edit,
              color: Colors.black,
            ),
            onPressed: () {
              setState(() {
                _isEditing = !_isEditing;
                if (!_isEditing) {
                  // Reset controllers to current values when canceling edit
                  _mobileNumberController.text =
                      _mobileNumber ?? 'Not provided';
                  _nationalAddressController.text =
                      _nationalAddress ?? 'Not provided';
                  _selectedBloodType = _selectedBloodType;
                }
              });
            },
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : Padding(
                padding: const EdgeInsets.all(16.0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: _isEditing ? _pickImage : null,
                        child: CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.grey[200],
                          backgroundImage:
                              _image != null ? FileImage(_image!) : null,
                          child:
                              _image == null
                                  ? Icon(
                                    Icons.camera_alt,
                                    size: 40,
                                    color: Colors.grey[600],
                                  )
                                  : null,
                        ),
                      ),
                      const SizedBox(height: 20),
                      _buildProfileInfo(
                        "$_firstName $_lastName",
                        "Name",
                        editable: false,
                      ),
                      _buildProfileInfo(
                        _email ?? 'No email provided',
                        "Email",
                        editable: false,
                      ),
                      _isEditing
                          ? _buildEditableField(
                            _mobileNumberController,
                            "Mobile Number",
                          )
                          : _buildProfileInfo(
                            _mobileNumber ?? 'Not provided',
                            "Mobile Number",
                          ),
                      _isEditing
                          ? _buildEditableField(
                            _nationalAddressController,
                            "National Address",
                          )
                          : _buildProfileInfo(
                            _nationalAddress ?? 'Not provided',
                            "National Address",
                          ),
                      _isEditing
                          ? _buildBloodTypeDropdown("Blood Type")
                          : _buildProfileInfo(_selectedBloodType, "Blood Type"),
                      if (_isEditing)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          child: ElevatedButton(
                            onPressed: _saveProfileData,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.purple,
                              minimumSize: const Size(double.infinity, 50),
                            ),
                            child: const Text(
                              "Save Profile",
                              style: TextStyle(
                                fontSize: 18,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
    );
  }

  Widget _buildProfileInfo(String value, String label, {bool editable = true}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 5),
          Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
        ],
      ),
    );
  }

  Widget _buildEditableField(TextEditingController controller, String label) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
          const SizedBox(height: 5),
          TextField(
            controller: controller,
            decoration: InputDecoration(
              // Removed 'const' here
              border: InputBorder.none,
              hintText: "Enter $label",
            ),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildBloodTypeDropdown(String label) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 14, color: Colors.grey[600])),
          const SizedBox(height: 5),
          DropdownButtonFormField<String>(
            value: _selectedBloodType,
            decoration: const InputDecoration(border: InputBorder.none),
            items:
                _bloodTypes
                    .map(
                      (type) => DropdownMenuItem(
                        value: type,
                        child: Text(type, style: const TextStyle(fontSize: 18)),
                      ),
                    )
                    .toList(),
            onChanged: (value) => setState(() => _selectedBloodType = value!),
          ),
        ],
      ),
    );
  }
}
