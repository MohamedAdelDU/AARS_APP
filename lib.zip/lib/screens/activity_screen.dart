import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import 'package:provider/provider.dart';
import '../providers/activity_provider.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class ActivityScreen extends StatelessWidget {
  const ActivityScreen({super.key});

  Future<void> _sendEmergencySMS(BuildContext context, String message) async {
    final contacts = await _loadContacts();
    if (context.mounted && contacts.isNotEmpty) {
      final phoneNumbers =
          contacts.map((contact) => contact['phone']!).toList();
      try {
        String result = await sendSMS(
          message: message,
          recipients: phoneNumbers,
          sendDirect: true,
        );
        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text("SMS sent: $result")));
        }
      } catch (e) {
        if (context.mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text("Error sending SMS: $e")));
        }
      }
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No emergency contacts available")),
      );
    }
  }

  Future<List<Map<String, String>>> _loadContacts() async {
    final prefs = await SharedPreferences.getInstance();
    final contactsJson = prefs.getStringList('emergencyContacts') ?? [];
    List<Map<String, String>> emergencyContacts = [];
    for (var contact in contactsJson) {
      emergencyContacts.add(Map<String, String>.from(jsonDecode(contact)));
    }
    return emergencyContacts;
  }

  @override
  Widget build(BuildContext context) {
    final activityProvider = Provider.of<ActivityProvider>(context);
    final activities = activityProvider.recentActivities;
    final distanceTraveled = activityProvider.distanceTraveled;
    final drivingRating = activityProvider.getDrivingRating();
    final accidentDetected = activityProvider.accidentDetected;

    if (accidentDetected) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder:
                (context) => AlertDialog(
                  title: const Text("Accident Detected"),
                  content: const Text(
                    "A potential accident was detected. Do you want to send an emergency alert?",
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        activityProvider.confirmAccident(false);
                        Navigator.pop(context);
                      },
                      child: const Text("Cancel"),
                    ),
                    TextButton(
                      onPressed: () {
                        activityProvider.confirmAccident(true);
                        _sendEmergencySMS(
                          context,
                          "Emergency: Accident detected! Please assist.",
                        );
                        Navigator.pop(context);
                      },
                      child: const Text("Send Alert"),
                    ),
                  ],
                ),
          );
        }
      });
    }

    double activityProgress = activities.length / 10.0;
    if (activityProgress > 1.0) activityProgress = 1.0;

    double distanceProgress = distanceTraveled / 1000.0;
    if (distanceProgress > 1.0) distanceProgress = 1.0;

    double ratingProgress;
    Color ratingColor;
    switch (drivingRating) {
      case "Dangerous":
        ratingProgress = 1.0;
        ratingColor = Colors.red;
        break;
      case "Normal":
        ratingProgress = 0.66;
        ratingColor = Colors.orange;
        break;
      case "Excellent":
      default:
        ratingProgress = 0.33;
        ratingColor = Colors.green;
        break;
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Recent Activities")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildCircularIndicator(
                    context: context,
                    percent: activityProgress,
                    label: "Activity",
                    centerText: "${(activityProgress * 100).toInt()}%",
                    footerText: "Recent activity level",
                    progressColor: Colors.green,
                    backgroundColor: Colors.grey[300]!,
                  ),
                  _buildCircularIndicator(
                    context: context,
                    percent: distanceProgress,
                    label: "Distance",
                    centerText: "${distanceTraveled.toStringAsFixed(1)} km",
                    footerText: "of 1000 km goal",
                    progressColor: Colors.blue,
                    backgroundColor: Colors.grey[300]!,
                  ),
                  _buildCircularIndicator(
                    context: context,
                    percent: ratingProgress,
                    label: "Driving",
                    centerText: drivingRating,
                    footerText: "Today's rating",
                    progressColor: ratingColor,
                    backgroundColor: Colors.grey[300]!,
                  ),
                ],
              ),
              const SizedBox(height: 20),
              const Text(
                "Daily Stats",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Card(
                elevation: 2,
                child: ListTile(
                  leading: const Icon(
                    Icons.directions_walk,
                    color: Colors.blue,
                  ),
                  title: const Text("Distance Traveled Today"),
                  subtitle: Text("${distanceTraveled.toStringAsFixed(2)} km"),
                ),
              ),
              Card(
                elevation: 2,
                child: ListTile(
                  leading: Icon(
                    drivingRating == "Dangerous"
                        ? Icons.warning
                        : drivingRating == "Normal"
                        ? Icons.directions_car
                        : Icons.star,
                    color:
                        drivingRating == "Dangerous"
                            ? Colors.red
                            : drivingRating == "Normal"
                            ? Colors.orange
                            : Colors.green,
                  ),
                  title: const Text("Driving Rating"),
                  subtitle: Text(drivingRating),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Recent Activities",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              activities.isEmpty
                  ? const Center(child: Text("No recent activities"))
                  : ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: activities.length,
                    itemBuilder:
                        (context, index) => ListTile(
                          leading: const Icon(
                            Icons.history,
                            color: Colors.grey,
                          ),
                          title: Text(activities[index]),
                        ),
                  ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCircularIndicator({
    required BuildContext context,
    required double percent,
    required String label,
    required String centerText,
    required String footerText,
    required Color progressColor,
    required Color backgroundColor,
  }) {
    return Column(
      children: [
        CircularPercentIndicator(
          radius: 50.0,
          lineWidth: 10.0,
          percent: percent,
          center: Text(
            centerText,
            style: const TextStyle(
              color: Colors.black,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          progressColor: progressColor,
          backgroundColor: backgroundColor,
          circularStrokeCap: CircularStrokeCap.round,
          animation: true,
          animationDuration: 500,
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 5),
        Text(
          footerText,
          style: const TextStyle(color: Colors.grey, fontSize: 12),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
