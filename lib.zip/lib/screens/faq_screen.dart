import 'package:flutter/material.dart';

class FAQScreen extends StatelessWidget {
  const FAQScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("FAQs")),
      body: ListView(
        children: const [
          ExpansionTile(
            title: Text("How do I reset my password?"),
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  "To reset your password, go to the 'Settings' screen and select 'Change Password'. Follow the instructions to reset your password.",
                ),
              ),
            ],
          ),
          ExpansionTile(
            title: Text("How do I enable notifications?"),
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  "Go to the 'Settings' screen and toggle the 'Enable Notifications' switch to turn notifications on or off.",
                ),
              ),
            ],
          ),
          ExpansionTile(
            title: Text("How do I contact support?"),
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: Text(
                  "You can contact support by visiting the 'Contact Support' section in the 'Support & Help' screen.",
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}