import 'package:flutter/material.dart';

class PrivacySecurityScreen extends StatelessWidget {
  const PrivacySecurityScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Privacy & Security")),
      body: ListView(
        children: [
          ListTile(
            title: const Text("Change Password"),
            onTap: () {},
          ),
          ListTile(
            title: const Text("Two-Factor Authentication"),
            onTap: () {},
          ),
          ListTile(
            title: const Text("Data Privacy"),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}